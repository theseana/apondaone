## Problem with notch shape in Boxplots

- problem occurs in `matplotlib 1.4.0`

- [View IPython Notebook](http://nbviewer.ipython.org/github/rasbt/matplotlib-gallery/blob/master/bugreport/boxplot_notch/boxplot_notch.ipynb)